# Graph Report - .  (2026-04-18)

## Corpus Check
- 84 files · ~89,162 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 199 nodes · 161 edges · 70 communities detected
- Extraction: 79% EXTRACTED · 21% INFERRED · 0% AMBIGUOUS · INFERRED: 34 edges (avg confidence: 0.81)
- Token cost: 10,000 input · 5,000 output

## Community Hubs (Navigation)
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 1|Module 1]]
- [[_COMMUNITY_Inventory System|Inventory System]]
- [[_COMMUNITY_Cloud Infrastructure|Cloud Infrastructure]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 5|Module 5]]
- [[_COMMUNITY_Order Management|Order Management]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 8|Module 8]]
- [[_COMMUNITY_Module 9|Module 9]]
- [[_COMMUNITY_Module 10|Module 10]]
- [[_COMMUNITY_Module 11|Module 11]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Order Management|Order Management]]
- [[_COMMUNITY_Module 14|Module 14]]
- [[_COMMUNITY_Module 15|Module 15]]
- [[_COMMUNITY_Module 16|Module 16]]
- [[_COMMUNITY_Module 17|Module 17]]
- [[_COMMUNITY_Module 18|Module 18]]
- [[_COMMUNITY_Frontend Components|Frontend Components]]
- [[_COMMUNITY_Module 20|Module 20]]
- [[_COMMUNITY_Module 21|Module 21]]
- [[_COMMUNITY_Module 22|Module 22]]
- [[_COMMUNITY_Module 23|Module 23]]
- [[_COMMUNITY_Module 24|Module 24]]
- [[_COMMUNITY_Module 25|Module 25]]
- [[_COMMUNITY_Module 26|Module 26]]
- [[_COMMUNITY_Module 27|Module 27]]
- [[_COMMUNITY_Module 28|Module 28]]
- [[_COMMUNITY_Inventory System|Inventory System]]
- [[_COMMUNITY_Order Management|Order Management]]
- [[_COMMUNITY_Inventory System|Inventory System]]
- [[_COMMUNITY_Inventory System|Inventory System]]
- [[_COMMUNITY_Module 33|Module 33]]
- [[_COMMUNITY_Module 34|Module 34]]
- [[_COMMUNITY_Module 35|Module 35]]
- [[_COMMUNITY_Module 36|Module 36]]
- [[_COMMUNITY_Module 37|Module 37]]
- [[_COMMUNITY_Module 38|Module 38]]
- [[_COMMUNITY_Module 39|Module 39]]
- [[_COMMUNITY_Module 40|Module 40]]
- [[_COMMUNITY_Module 41|Module 41]]
- [[_COMMUNITY_Module 42|Module 42]]
- [[_COMMUNITY_Module 43|Module 43]]
- [[_COMMUNITY_Module 44|Module 44]]
- [[_COMMUNITY_Module 45|Module 45]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 47|Module 47]]
- [[_COMMUNITY_Module 48|Module 48]]
- [[_COMMUNITY_Module 49|Module 49]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 51|Module 51]]
- [[_COMMUNITY_Inventory System|Inventory System]]
- [[_COMMUNITY_Module 53|Module 53]]
- [[_COMMUNITY_Module 54|Module 54]]
- [[_COMMUNITY_Inventory System|Inventory System]]
- [[_COMMUNITY_Order Management|Order Management]]
- [[_COMMUNITY_Order Management|Order Management]]
- [[_COMMUNITY_Module 58|Module 58]]
- [[_COMMUNITY_Module 59|Module 59]]
- [[_COMMUNITY_Module 60|Module 60]]
- [[_COMMUNITY_Module 61|Module 61]]
- [[_COMMUNITY_Order Management|Order Management]]
- [[_COMMUNITY_Module 63|Module 63]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 65|Module 65]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 67|Module 67]]
- [[_COMMUNITY_Authentication|Authentication]]
- [[_COMMUNITY_Module 69|Module 69]]

## God Nodes (most connected - your core abstractions)
1. `useAuth()` - 15 edges
2. `formatDateTime()` - 9 edges
3. `statusColor()` - 6 edges
4. `PaymentDetailModal()` - 5 edges
5. `OrderDetailModal()` - 5 edges
6. `formatCurrency()` - 5 edges
7. `Sidebar()` - 4 edges
8. `AdminReviewModal()` - 4 edges
9. `DetailModal()` - 4 edges
10. `RAPS ERP System` - 4 edges

## Surprising Connections (you probably didn't know these)
- `PaymentRequests()` --calls--> `useAuth()`  [INFERRED]
  client\src\pages\PaymentRequests.jsx → client\src\context\AuthContext.jsx
- `PurchaseRequests()` --calls--> `useAuth()`  [INFERRED]
  client\src\pages\PurchaseRequests.jsx → client\src\context\AuthContext.jsx
- `QCInspections()` --calls--> `useAuth()`  [INFERRED]
  client\src\pages\QCInspections.jsx → client\src\context\AuthContext.jsx
- `QuotationManagement()` --calls--> `useAuth()`  [INFERRED]
  client\src\pages\QuotationManagement.jsx → client\src\context\AuthContext.jsx
- `PrivateRoute()` --calls--> `useAuth()`  [INFERRED]
  client\src\App.jsx → client\src\context\AuthContext.jsx

## Communities

### Community 0 - "Authentication"
Cohesion: 0.09
Nodes (9): App(), PrivateRoute(), useAuth(), Dashboard(), ManagerDashboard(), Header(), Login(), Products() (+1 more)

### Community 1 - "Module 1"
Cohesion: 0.19
Nodes (9): AllRequests(), formatDateTime(), MyRequests(), AdminReviewModal(), DetailModal(), PurchaseRequests(), statusColor(), statusLabel() (+1 more)

### Community 2 - "Inventory System"
Cohesion: 0.16
Nodes (7): DeadStock(), formatDate(), InvoiceDetail(), AddQuotationModal(), formatCurrency(), QuotationManagement(), SaleOrderForm()

### Community 3 - "Cloud Infrastructure"
Cohesion: 0.18
Nodes (11): AWS Cloud Architecture, RAPS ERP Cloud Migration Plan, AWS EC2 Instance, Express.js, Node.js, PostgreSQL, Prisma ORM, RAPS ERP System (+3 more)

### Community 4 - "Authentication"
Cohesion: 0.33
Nodes (3): getNavItems(), Sidebar(), roleLabel()

### Community 5 - "Module 5"
Cohesion: 0.33
Nodes (2): roleLabel(), UsersSection()

### Community 6 - "Order Management"
Cohesion: 0.48
Nodes (5): formatCurrency(), OrderDetailModal(), PurchaseOrders(), statusColor(), statusLabel()

### Community 7 - "Authentication"
Cohesion: 0.29
Nodes (2): authenticate(), verifyAccessToken()

### Community 8 - "Module 8"
Cohesion: 0.53
Nodes (5): formatCurrency(), PaymentDetailModal(), PaymentRequests(), statusColor(), typeColor()

### Community 9 - "Module 9"
Cohesion: 0.5
Nodes (3): formatCurrency(), InspectionModal(), QCInspections()

### Community 10 - "Module 10"
Cohesion: 0.5
Nodes (0): 

### Community 11 - "Module 11"
Cohesion: 0.67
Nodes (0): 

### Community 12 - "Authentication"
Cohesion: 0.67
Nodes (0): 

### Community 13 - "Order Management"
Cohesion: 0.67
Nodes (0): 

### Community 14 - "Module 14"
Cohesion: 1.0
Nodes (0): 

### Community 15 - "Module 15"
Cohesion: 1.0
Nodes (0): 

### Community 16 - "Module 16"
Cohesion: 1.0
Nodes (0): 

### Community 17 - "Module 17"
Cohesion: 1.0
Nodes (0): 

### Community 18 - "Module 18"
Cohesion: 1.0
Nodes (0): 

### Community 19 - "Frontend Components"
Cohesion: 1.0
Nodes (0): 

### Community 20 - "Module 20"
Cohesion: 1.0
Nodes (0): 

### Community 21 - "Module 21"
Cohesion: 1.0
Nodes (0): 

### Community 22 - "Module 22"
Cohesion: 1.0
Nodes (0): 

### Community 23 - "Module 23"
Cohesion: 1.0
Nodes (0): 

### Community 24 - "Module 24"
Cohesion: 1.0
Nodes (0): 

### Community 25 - "Module 25"
Cohesion: 1.0
Nodes (0): 

### Community 26 - "Module 26"
Cohesion: 1.0
Nodes (0): 

### Community 27 - "Module 27"
Cohesion: 1.0
Nodes (0): 

### Community 28 - "Module 28"
Cohesion: 1.0
Nodes (0): 

### Community 29 - "Inventory System"
Cohesion: 1.0
Nodes (0): 

### Community 30 - "Order Management"
Cohesion: 1.0
Nodes (0): 

### Community 31 - "Inventory System"
Cohesion: 1.0
Nodes (0): 

### Community 32 - "Inventory System"
Cohesion: 1.0
Nodes (0): 

### Community 33 - "Module 33"
Cohesion: 1.0
Nodes (0): 

### Community 34 - "Module 34"
Cohesion: 1.0
Nodes (0): 

### Community 35 - "Module 35"
Cohesion: 1.0
Nodes (0): 

### Community 36 - "Module 36"
Cohesion: 1.0
Nodes (0): 

### Community 37 - "Module 37"
Cohesion: 1.0
Nodes (0): 

### Community 38 - "Module 38"
Cohesion: 1.0
Nodes (0): 

### Community 39 - "Module 39"
Cohesion: 1.0
Nodes (0): 

### Community 40 - "Module 40"
Cohesion: 1.0
Nodes (0): 

### Community 41 - "Module 41"
Cohesion: 1.0
Nodes (0): 

### Community 42 - "Module 42"
Cohesion: 1.0
Nodes (0): 

### Community 43 - "Module 43"
Cohesion: 1.0
Nodes (0): 

### Community 44 - "Module 44"
Cohesion: 1.0
Nodes (0): 

### Community 45 - "Module 45"
Cohesion: 1.0
Nodes (0): 

### Community 46 - "Authentication"
Cohesion: 1.0
Nodes (0): 

### Community 47 - "Module 47"
Cohesion: 1.0
Nodes (0): 

### Community 48 - "Module 48"
Cohesion: 1.0
Nodes (0): 

### Community 49 - "Module 49"
Cohesion: 1.0
Nodes (0): 

### Community 50 - "Authentication"
Cohesion: 1.0
Nodes (0): 

### Community 51 - "Module 51"
Cohesion: 1.0
Nodes (0): 

### Community 52 - "Inventory System"
Cohesion: 1.0
Nodes (0): 

### Community 53 - "Module 53"
Cohesion: 1.0
Nodes (0): 

### Community 54 - "Module 54"
Cohesion: 1.0
Nodes (0): 

### Community 55 - "Inventory System"
Cohesion: 1.0
Nodes (0): 

### Community 56 - "Order Management"
Cohesion: 1.0
Nodes (0): 

### Community 57 - "Order Management"
Cohesion: 1.0
Nodes (0): 

### Community 58 - "Module 58"
Cohesion: 1.0
Nodes (0): 

### Community 59 - "Module 59"
Cohesion: 1.0
Nodes (0): 

### Community 60 - "Module 60"
Cohesion: 1.0
Nodes (0): 

### Community 61 - "Module 61"
Cohesion: 1.0
Nodes (0): 

### Community 62 - "Order Management"
Cohesion: 1.0
Nodes (0): 

### Community 63 - "Module 63"
Cohesion: 1.0
Nodes (0): 

### Community 64 - "Authentication"
Cohesion: 1.0
Nodes (0): 

### Community 65 - "Module 65"
Cohesion: 1.0
Nodes (0): 

### Community 66 - "Authentication"
Cohesion: 1.0
Nodes (1): JWT Authentication

### Community 67 - "Module 67"
Cohesion: 1.0
Nodes (1): Progressive Web App Model

### Community 68 - "Authentication"
Cohesion: 1.0
Nodes (1): Security Requirements

### Community 69 - "Module 69"
Cohesion: 1.0
Nodes (1): RAPS Logo

## Knowledge Gaps
- **10 isolated node(s):** `React 18`, `Express.js`, `Prisma ORM`, `JWT Authentication`, `Progressive Web App Model` (+5 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **Thin community `Module 14`** (2 nodes): `MainLayout.jsx`, `MainLayout()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 15`** (2 nodes): `Pagination.jsx`, `Pagination()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 16`** (2 nodes): `SearchBar.jsx`, `SearchBar()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 17`** (2 nodes): `StatsCard.jsx`, `StatsCard()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 18`** (2 nodes): `Badge()`, `Badge.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Frontend Components`** (2 nodes): `Button()`, `Button.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 20`** (2 nodes): `Card()`, `Card.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 21`** (2 nodes): `Modal.jsx`, `Modal()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 22`** (2 nodes): `Table.jsx`, `Table()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 23`** (2 nodes): `useFetch.js`, `useFetch()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 24`** (2 nodes): `AuditLogs()`, `AuditLogs.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 25`** (2 nodes): `Customers.jsx`, `Customers()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 26`** (2 nodes): `Invoices.jsx`, `Invoices()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 27`** (2 nodes): `InwardEntry.jsx`, `InwardEntry()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 28`** (2 nodes): `Notifications.jsx`, `Notifications()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Inventory System`** (2 nodes): `ProductDetail.jsx`, `ProductDetail()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Order Management`** (2 nodes): `SaleOrders.jsx`, `SaleOrders()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Inventory System`** (2 nodes): `StockMovements.jsx`, `StockMovements()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Inventory System`** (2 nodes): `StockTransfers.jsx`, `StockTransfers()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 33`** (2 nodes): `Units.jsx`, `Units()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 34`** (2 nodes): `UnitUsageLogs.jsx`, `UnitUsageLogs()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 35`** (2 nodes): `WarehouseDetail.jsx`, `WarehouseDetail()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 36`** (2 nodes): `Warehouses.jsx`, `Warehouses()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 37`** (2 nodes): `addAdmins()`, `add-admins.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 38`** (2 nodes): `main()`, `seed-data.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 39`** (2 nodes): `main()`, `seed.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 40`** (2 nodes): `auditLog()`, `audit.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 41`** (1 nodes): `postcss.config.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 42`** (1 nodes): `tailwind.config.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 43`** (1 nodes): `vite.config.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 44`** (1 nodes): `main.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 45`** (1 nodes): `axios.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Authentication`** (1 nodes): `useAuth.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 47`** (1 nodes): `index.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 48`** (1 nodes): `db.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 49`** (1 nodes): `alert.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Authentication`** (1 nodes): `auth.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 51`** (1 nodes): `customer.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Inventory System`** (1 nodes): `inventory.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 53`** (1 nodes): `invoice.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 54`** (1 nodes): `paymentRequest.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Inventory System`** (1 nodes): `product.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Order Management`** (1 nodes): `purchaseOrder.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Order Management`** (1 nodes): `purchaseRequest.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 58`** (1 nodes): `qcInspection.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 59`** (1 nodes): `quotation.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 60`** (1 nodes): `report.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 61`** (1 nodes): `request.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Order Management`** (1 nodes): `sale.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 63`** (1 nodes): `unit.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Authentication`** (1 nodes): `user.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 65`** (1 nodes): `warehouse.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Authentication`** (1 nodes): `JWT Authentication`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 67`** (1 nodes): `Progressive Web App Model`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Authentication`** (1 nodes): `Security Requirements`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Module 69`** (1 nodes): `RAPS Logo`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `useAuth()` connect `Authentication` to `Module 1`, `Inventory System`, `Authentication`, `Order Management`, `Module 8`, `Module 9`?**
  _High betweenness centrality (0.102) - this node is a cross-community bridge._
- **Why does `formatDateTime()` connect `Module 1` to `Module 8`, `Module 9`, `Inventory System`, `Order Management`?**
  _High betweenness centrality (0.034) - this node is a cross-community bridge._
- **Why does `PurchaseRequests()` connect `Module 1` to `Authentication`?**
  _High betweenness centrality (0.027) - this node is a cross-community bridge._
- **Are the 14 inferred relationships involving `useAuth()` (e.g. with `PrivateRoute()` and `App()`) actually correct?**
  _`useAuth()` has 14 INFERRED edges - model-reasoned connections that need verification._
- **Are the 8 inferred relationships involving `formatDateTime()` (e.g. with `AllRequests()` and `MyRequests()`) actually correct?**
  _`formatDateTime()` has 8 INFERRED edges - model-reasoned connections that need verification._
- **Are the 3 inferred relationships involving `statusColor()` (e.g. with `AllRequests()` and `MyRequests()`) actually correct?**
  _`statusColor()` has 3 INFERRED edges - model-reasoned connections that need verification._
- **What connects `React 18`, `Express.js`, `Prisma ORM` to the rest of the system?**
  _10 weakly-connected nodes found - possible documentation gaps or missing edges._