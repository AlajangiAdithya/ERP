# Graph Report - .  (2026-04-25)

## Corpus Check
- 65 files · ~58,942 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 217 nodes · 249 edges · 45 communities detected
- Extraction: 77% EXTRACTED · 23% INFERRED · 0% AMBIGUOUS · INFERRED: 57 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- [[_COMMUNITY_App Shell & Role Dashboards|App Shell & Role Dashboards]]
- [[_COMMUNITY_Purchase Requests|Purchase Requests]]
- [[_COMMUNITY_Printable PDF Documents|Printable PDF Documents]]
- [[_COMMUNITY_Purchase Orders & Tier Approvals|Purchase Orders & Tier Approvals]]
- [[_COMMUNITY_Payments & Inventory Transfers|Payments & Inventory Transfers]]
- [[_COMMUNITY_Quotations & Invoices|Quotations & Invoices]]
- [[_COMMUNITY_QC Inspections|QC Inspections]]
- [[_COMMUNITY_Sidebar & User Roles|Sidebar & User Roles]]
- [[_COMMUNITY_Gate Pass Workflow|Gate Pass Workflow]]
- [[_COMMUNITY_Inter Office Notes|Inter Office Notes]]
- [[_COMMUNITY_Inward Entry|Inward Entry]]
- [[_COMMUNITY_Admin Management|Admin Management]]
- [[_COMMUNITY_Brand & Domain Concepts|Brand & Domain Concepts]]
- [[_COMMUNITY_Shared PDF Helpers|Shared PDF Helpers]]
- [[_COMMUNITY_Input Form Controls|Input Form Controls]]
- [[_COMMUNITY_Dropdown Component|Dropdown Component]]
- [[_COMMUNITY_Main Layout|Main Layout]]
- [[_COMMUNITY_PDF Download Button|PDF Download Button]]
- [[_COMMUNITY_Pagination|Pagination]]
- [[_COMMUNITY_Search Bar|Search Bar]]
- [[_COMMUNITY_Stats Card|Stats Card]]
- [[_COMMUNITY_Badge UI|Badge UI]]
- [[_COMMUNITY_Button UI|Button UI]]
- [[_COMMUNITY_Card UI|Card UI]]
- [[_COMMUNITY_Modal UI|Modal UI]]
- [[_COMMUNITY_Table UI|Table UI]]
- [[_COMMUNITY_useFetch Hook|useFetch Hook]]
- [[_COMMUNITY_Audit Logs Page|Audit Logs Page]]
- [[_COMMUNITY_Customers Page|Customers Page]]
- [[_COMMUNITY_Invoices Page|Invoices Page]]
- [[_COMMUNITY_Notifications Page|Notifications Page]]
- [[_COMMUNITY_Product Detail|Product Detail]]
- [[_COMMUNITY_Sale Orders|Sale Orders]]
- [[_COMMUNITY_Stock Movements|Stock Movements]]
- [[_COMMUNITY_Stock Transfers|Stock Transfers]]
- [[_COMMUNITY_Units Page|Units Page]]
- [[_COMMUNITY_Unit Usage Logs|Unit Usage Logs]]
- [[_COMMUNITY_Warehouse Detail|Warehouse Detail]]
- [[_COMMUNITY_Warehouses Page|Warehouses Page]]
- [[_COMMUNITY_PostCSS Config|PostCSS Config]]
- [[_COMMUNITY_Tailwind Config|Tailwind Config]]
- [[_COMMUNITY_Vite Config|Vite Config]]
- [[_COMMUNITY_Entry Point|Entry Point]]
- [[_COMMUNITY_Axios API Client|Axios API Client]]
- [[_COMMUNITY_useAuth Hook|useAuth Hook]]

## God Nodes (most connected - your core abstractions)
1. `formatDateTime()` - 19 edges
2. `useAuth()` - 18 edges
3. `formatDate()` - 11 edges
4. `PaymentDetailModal()` - 9 edges
5. `OrderDetailModal()` - 7 edges
6. `GatePassPdf()` - 6 edges
7. `statusColor()` - 6 edges
8. `formatCurrency()` - 6 edges
9. `DetailModal()` - 5 edges
10. `InventoryTransfers()` - 5 edges

## Surprising Connections (you probably didn't know these)
- `InterOfficeNote()` --calls--> `useAuth()`  [INFERRED]
  src\pages\InterOfficeNote.jsx → src\context\AuthContext.jsx
- `CreateRequestModal()` --calls--> `useAuth()`  [INFERRED]
  src\pages\PurchaseRequests.jsx → src\context\AuthContext.jsx
- `PurchaseRequests()` --calls--> `useAuth()`  [INFERRED]
  src\pages\PurchaseRequests.jsx → src\context\AuthContext.jsx
- `QCInspections()` --calls--> `useAuth()`  [INFERRED]
  src\pages\QCInspections.jsx → src\context\AuthContext.jsx
- `QuotationManagement()` --calls--> `useAuth()`  [INFERRED]
  src\pages\QuotationManagement.jsx → src\context\AuthContext.jsx

## Communities

### Community 0 - "App Shell & Role Dashboards"
Cohesion: 0.09
Nodes (10): App(), PrivateRoute(), useAuth(), Dashboard(), ManagerDashboard(), Header(), Login(), PaymentRequests() (+2 more)

### Community 1 - "Purchase Requests"
Cohesion: 0.16
Nodes (11): AllRequests(), formatDateTime(), MyRequests(), AdminReviewModal(), CreateRequestModal(), DetailModal(), ProcurementJourney(), PurchaseRequests() (+3 more)

### Community 2 - "Printable PDF Documents"
Cohesion: 0.15
Nodes (10): formatDate(), GatePassPdf(), statusLabel(), typeForm(), typeLabel(), InwardPdf(), IONPdf(), statusLabel() (+2 more)

### Community 3 - "Purchase Orders & Tier Approvals"
Cohesion: 0.26
Nodes (10): formatCurrency(), getTier(), OrderDetailModal(), PRGroup(), PurchaseOrders(), statusColor(), statusLabel(), SupplierGroup() (+2 more)

### Community 4 - "Payments & Inventory Transfers"
Cohesion: 0.28
Nodes (11): InventoryTransfers(), statusColor(), canApprove(), formatCurrency(), getTier(), normName(), PaymentDetailModal(), statusColor() (+3 more)

### Community 5 - "Quotations & Invoices"
Cohesion: 0.17
Nodes (8): DeadStock(), InvoiceDetail(), POPdf(), AddQuotationModal(), formatCurrency(), QuotationManagement(), ReviewQuotationsModal(), SaleOrderForm()

### Community 6 - "QC Inspections"
Cohesion: 0.36
Nodes (7): FillReportModal(), fmtDate(), formatCurrency(), OrderInfoHeader(), QCInspections(), resultColor(), ViewInspectionModal()

### Community 7 - "Sidebar & User Roles"
Cohesion: 0.33
Nodes (3): getNavItems(), Sidebar(), roleLabel()

### Community 8 - "Gate Pass Workflow"
Cohesion: 0.38
Nodes (3): DetailModal(), statusColor(), statusLabel()

### Community 9 - "Inter Office Notes"
Cohesion: 0.38
Nodes (4): DetailModal(), InterOfficeNote(), statusColor(), statusLabel()

### Community 10 - "Inward Entry"
Cohesion: 0.29
Nodes (0): 

### Community 11 - "Admin Management"
Cohesion: 0.33
Nodes (2): roleLabel(), UsersSection()

### Community 12 - "Brand & Domain Concepts"
Cohesion: 0.38
Nodes (7): Aerospace Industry, AS9100D Certification, Navy Blue Color, Red Color, RAPS, RAPS Logo, Red Rocket/Arrow Motif (A letter)

### Community 13 - "Shared PDF Helpers"
Cohesion: 0.33
Nodes (0): 

### Community 14 - "Input Form Controls"
Cohesion: 0.5
Nodes (0): 

### Community 15 - "Dropdown Component"
Cohesion: 0.67
Nodes (0): 

### Community 16 - "Main Layout"
Cohesion: 1.0
Nodes (0): 

### Community 17 - "PDF Download Button"
Cohesion: 1.0
Nodes (0): 

### Community 18 - "Pagination"
Cohesion: 1.0
Nodes (0): 

### Community 19 - "Search Bar"
Cohesion: 1.0
Nodes (0): 

### Community 20 - "Stats Card"
Cohesion: 1.0
Nodes (0): 

### Community 21 - "Badge UI"
Cohesion: 1.0
Nodes (0): 

### Community 22 - "Button UI"
Cohesion: 1.0
Nodes (0): 

### Community 23 - "Card UI"
Cohesion: 1.0
Nodes (0): 

### Community 24 - "Modal UI"
Cohesion: 1.0
Nodes (0): 

### Community 25 - "Table UI"
Cohesion: 1.0
Nodes (0): 

### Community 26 - "useFetch Hook"
Cohesion: 1.0
Nodes (0): 

### Community 27 - "Audit Logs Page"
Cohesion: 1.0
Nodes (0): 

### Community 28 - "Customers Page"
Cohesion: 1.0
Nodes (0): 

### Community 29 - "Invoices Page"
Cohesion: 1.0
Nodes (0): 

### Community 30 - "Notifications Page"
Cohesion: 1.0
Nodes (0): 

### Community 31 - "Product Detail"
Cohesion: 1.0
Nodes (0): 

### Community 32 - "Sale Orders"
Cohesion: 1.0
Nodes (0): 

### Community 33 - "Stock Movements"
Cohesion: 1.0
Nodes (0): 

### Community 34 - "Stock Transfers"
Cohesion: 1.0
Nodes (0): 

### Community 35 - "Units Page"
Cohesion: 1.0
Nodes (0): 

### Community 36 - "Unit Usage Logs"
Cohesion: 1.0
Nodes (0): 

### Community 37 - "Warehouse Detail"
Cohesion: 1.0
Nodes (0): 

### Community 38 - "Warehouses Page"
Cohesion: 1.0
Nodes (0): 

### Community 39 - "PostCSS Config"
Cohesion: 1.0
Nodes (0): 

### Community 40 - "Tailwind Config"
Cohesion: 1.0
Nodes (0): 

### Community 41 - "Vite Config"
Cohesion: 1.0
Nodes (0): 

### Community 42 - "Entry Point"
Cohesion: 1.0
Nodes (0): 

### Community 43 - "Axios API Client"
Cohesion: 1.0
Nodes (0): 

### Community 44 - "useAuth Hook"
Cohesion: 1.0
Nodes (0): 

## Knowledge Gaps
- **2 isolated node(s):** `Navy Blue Color`, `Red Color`
  These have ≤1 connection - possible missing edges or undocumented components.
- **Thin community `Main Layout`** (2 nodes): `MainLayout()`, `MainLayout.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `PDF Download Button`** (2 nodes): `DownloadPdfButton()`, `DownloadPdfButton.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Pagination`** (2 nodes): `Pagination()`, `Pagination.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Search Bar`** (2 nodes): `SearchBar()`, `SearchBar.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Stats Card`** (2 nodes): `StatsCard.jsx`, `StatsCard()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Badge UI`** (2 nodes): `Badge()`, `Badge.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Button UI`** (2 nodes): `Button()`, `Button.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Card UI`** (2 nodes): `Card()`, `Card.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Modal UI`** (2 nodes): `Modal()`, `Modal.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Table UI`** (2 nodes): `Table.jsx`, `Table()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `useFetch Hook`** (2 nodes): `useFetch.js`, `useFetch()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Audit Logs Page`** (2 nodes): `AuditLogs()`, `AuditLogs.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Customers Page`** (2 nodes): `Customers()`, `Customers.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Invoices Page`** (2 nodes): `Invoices()`, `Invoices.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Notifications Page`** (2 nodes): `Notifications()`, `Notifications.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Product Detail`** (2 nodes): `ProductDetail()`, `ProductDetail.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Sale Orders`** (2 nodes): `SaleOrders()`, `SaleOrders.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Stock Movements`** (2 nodes): `StockMovements.jsx`, `StockMovements()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Stock Transfers`** (2 nodes): `StockTransfers.jsx`, `StockTransfers()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Units Page`** (2 nodes): `Units.jsx`, `Units()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Unit Usage Logs`** (2 nodes): `UnitUsageLogs.jsx`, `UnitUsageLogs()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Warehouse Detail`** (2 nodes): `WarehouseDetail.jsx`, `WarehouseDetail()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Warehouses Page`** (2 nodes): `Warehouses.jsx`, `Warehouses()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `PostCSS Config`** (1 nodes): `postcss.config.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Tailwind Config`** (1 nodes): `tailwind.config.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Vite Config`** (1 nodes): `vite.config.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Entry Point`** (1 nodes): `main.jsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Axios API Client`** (1 nodes): `axios.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `useAuth Hook`** (1 nodes): `useAuth.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `useAuth()` connect `App Shell & Role Dashboards` to `Purchase Requests`, `Purchase Orders & Tier Approvals`, `Payments & Inventory Transfers`, `Quotations & Invoices`, `QC Inspections`, `Sidebar & User Roles`, `Inter Office Notes`?**
  _High betweenness centrality (0.216) - this node is a cross-community bridge._
- **Why does `formatDateTime()` connect `Purchase Requests` to `Printable PDF Documents`, `Payments & Inventory Transfers`, `Quotations & Invoices`, `QC Inspections`, `Gate Pass Workflow`?**
  _High betweenness centrality (0.165) - this node is a cross-community bridge._
- **Why does `InventoryTransfers()` connect `Payments & Inventory Transfers` to `App Shell & Role Dashboards`, `Purchase Requests`?**
  _High betweenness centrality (0.092) - this node is a cross-community bridge._
- **Are the 18 inferred relationships involving `formatDateTime()` (e.g. with `GatePassPdf()` and `InwardPdf()`) actually correct?**
  _`formatDateTime()` has 18 INFERRED edges - model-reasoned connections that need verification._
- **Are the 17 inferred relationships involving `useAuth()` (e.g. with `PrivateRoute()` and `App()`) actually correct?**
  _`useAuth()` has 17 INFERRED edges - model-reasoned connections that need verification._
- **Are the 10 inferred relationships involving `formatDate()` (e.g. with `GatePassPdf()` and `InwardPdf()`) actually correct?**
  _`formatDate()` has 10 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Navy Blue Color`, `Red Color` to the rest of the system?**
  _2 weakly-connected nodes found - possible documentation gaps or missing edges._