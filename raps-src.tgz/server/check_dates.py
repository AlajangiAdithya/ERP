"""Check date ranges of IN-2025 vs IN-2026 to detect overlap."""
import os, sys
from openpyxl import load_workbook

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
ROOT = r"C:\Users\alaja\Documents\RAPS formats and stocks"

for f, sheet, hdr in [("IN-2025.xlsx", "INWARD-2025", 3), ("IN-2026.xlsx", "INWARD-2026", 1)]:
    p = os.path.join(ROOT, f)
    wb = load_workbook(p, data_only=True, read_only=True)
    ws = wb[sheet]
    dates = []
    mirs = []
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i < hdr:
            continue
        if not row: continue
        d = row[2] if len(row) > 2 else None
        m = row[1] if len(row) > 1 else None
        if d and hasattr(d, 'year'):
            dates.append(d)
        if m is not None:
            mirs.append(str(m))
    wb.close()
    if dates:
        print(f"{f} :: {sheet}")
        print(f"  date range: {min(dates)} → {max(dates)}")
        print(f"  total rows with date: {len(dates)}")
        print(f"  first 5 MIRs: {mirs[:5]}")
        print(f"  last 5 MIRs: {mirs[-5:]}")
