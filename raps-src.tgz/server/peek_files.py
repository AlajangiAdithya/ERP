"""Peek first 8 rows of relevant sheets to plan import mapping."""
import os, sys
from openpyxl import load_workbook

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r"C:\Users\alaja\Documents\RAPS formats and stocks"

TARGETS = [
    ("IN-2025.xlsx", "INWARD-2025"),
    ("Inward Status File.xlsx", "2025-26"),
    ("Inward Status File.xlsx", "April"),
    ("Systems Data.xlsx", "Sheet1"),
    ("PR & PO File Final 2025-2026 v1.xlsx", "trinadh"),
    ("PR & PO File Final 2025-2026 v1.xlsx", "trinadh outward"),
]

for fname, sname in TARGETS:
    p = os.path.join(ROOT, fname)
    print(f"\n=== {fname} :: {sname} ===")
    try:
        wb = load_workbook(p, data_only=True, read_only=True)
        ws = wb[sname]
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i >= 8:
                break
            cells = [str(c)[:35] if c is not None else '' for c in row[:22]]
            print(f"  R{i}: {cells}")
        wb.close()
    except Exception as e:
        print(f"  ERROR: {e}")
