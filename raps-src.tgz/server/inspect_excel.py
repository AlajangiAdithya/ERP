"""Inspect all Excel files in RAPS formats and stocks folder."""
import os
import sys
from openpyxl import load_workbook

FOLDER = r"C:\Users\alaja\Documents\RAPS formats and stocks"

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

def list_xlsx(folder):
    for root, dirs, files in os.walk(folder):
        for f in files:
            if f.lower().endswith('.xlsx') and not f.startswith('~$'):
                yield os.path.join(root, f)

def inspect(path):
    rel = os.path.relpath(path, FOLDER)
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
    except Exception as e:
        print(f"\n=== {rel} ===\nERROR: {e}")
        return
    print(f"\n=== {rel} ===")
    for sn in wb.sheetnames:
        try:
            ws = wb[sn]
            max_row = ws.max_row
            max_col = ws.max_column
            print(f"  Sheet: '{sn}' rows={max_row} cols={max_col}")
            # Print first 5 rows
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= 5:
                    break
                cells = [str(c)[:40] if c is not None else '' for c in row[:max_col]]
                print(f"    R{i+1}: {cells}")
        except Exception as e:
            print(f"  Sheet '{sn}' ERROR: {e}")
    wb.close()

for p in list_xlsx(FOLDER):
    inspect(p)
