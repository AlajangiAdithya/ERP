"""Focused inspection of key Excel files for ERP import."""
import os, sys
from openpyxl import load_workbook

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

FOLDER = r"C:\Users\alaja\Documents\RAPS formats and stocks"

# Most relevant files for the ERP
KEY_FILES = [
    "NEW STOCK.xlsx",
    "Stock Demo-1.xlsx",
    "Stock Demo-2.xlsx",
    "Systems Data.xlsx",
    "IN-2025.xlsx",
    "IN-2026.xlsx",
    "Inward Status File.xlsx",
    "PR & PO File 2026-27.xlsx",
    "RAPS PR & PO File Final 2025-2026.xlsx",
]

def inspect(path, max_rows=10):
    print(f"\n=== {os.path.basename(path)} ===")
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
    except Exception as e:
        print(f"ERROR: {e}")
        return
    for sn in wb.sheetnames:
        try:
            ws = wb[sn]
            print(f"\n  --- Sheet: '{sn}' ---")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= max_rows:
                    print(f"    ... (truncated)")
                    break
                # Only show columns with at least some non-empty
                cells = [str(c)[:50].strip() if c is not None else '' for c in row]
                while cells and cells[-1] == '':
                    cells.pop()
                if cells:
                    print(f"    R{i+1}: {cells}")
        except Exception as e:
            print(f"  Sheet '{sn}' ERROR: {e}")
    wb.close()

for f in KEY_FILES:
    p = os.path.join(FOLDER, f)
    if os.path.exists(p):
        inspect(p)
    else:
        print(f"MISSING: {f}")
