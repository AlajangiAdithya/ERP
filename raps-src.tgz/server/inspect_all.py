"""Inspect all remaining Excel files - sheets, headers, row counts."""
import os, sys
from openpyxl import load_workbook

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r"C:\Users\alaja\Documents\RAPS formats and stocks"

FILES = [
    "IN-2025.xlsx",
    "Inward Status File.xlsx",
    "PR & PO File Final 2025-2026 V 12.xlsx",
    "PR & PO File Final 2025-2026 v1.xlsx",
    "RAPS PR & PO File Final 2025-2026.xlsx",
    "Stock Demo-1.xlsx",
    "Stock Demo-2.xlsx",
    "Systems Data.xlsx",
    "Daily Works.xlsx",
]

def inspect(path):
    wb = load_workbook(path, data_only=True, read_only=True)
    out = []
    for s in wb.sheetnames:
        ws = wb[s]
        rows = list(ws.iter_rows(values_only=True))
        nonempty = sum(1 for r in rows if any(c is not None and str(c).strip() for c in r))
        # find first non-empty row -> likely header
        header = None
        header_idx = None
        for i, r in enumerate(rows[:5]):
            if r and any(c is not None and str(c).strip() for c in r):
                header = r
                header_idx = i
                break
        out.append((s, len(rows), nonempty, header_idx, header))
    wb.close()
    return out

for f in FILES:
    p = os.path.join(ROOT, f)
    print(f"\n=== {f} ===")
    if not os.path.exists(p):
        print("  NOT FOUND")
        continue
    try:
        for s, total, nonempty, hidx, hdr in inspect(p):
            print(f"  Sheet: {s!r} | total_rows={total} | nonempty={nonempty} | header_row={hidx}")
            if hdr:
                cols = [str(c)[:40] if c else '' for c in hdr[:20]]
                print(f"    cols: {cols}")
    except Exception as e:
        print(f"  ERROR: {e}")
