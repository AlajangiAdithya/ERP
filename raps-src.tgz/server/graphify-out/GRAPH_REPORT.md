# Graph Report - .  (2026-04-19)

## Corpus Check
- Corpus is ~25,673 words - fits in a single context window. You may not need a graph.

## Summary
- 44 nodes · 15 edges · 30 communities detected
- Extraction: 93% EXTRACTED · 7% INFERRED · 0% AMBIGUOUS · INFERRED: 1 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- [[_COMMUNITY_JWT Token Utilities|JWT Token Utilities]]
- [[_COMMUNITY_Authentication Middleware|Authentication Middleware]]
- [[_COMMUNITY_RBAC Authorization|RBAC Authorization]]
- [[_COMMUNITY_Helpers (order numbers, pagination)|Helpers (order numbers, pagination)]]
- [[_COMMUNITY_Admin Seeder|Admin Seeder]]
- [[_COMMUNITY_Seed Data Script|Seed Data Script]]
- [[_COMMUNITY_DB Seed Script|DB Seed Script]]
- [[_COMMUNITY_Audit Logger|Audit Logger]]
- [[_COMMUNITY_Quotation PO-Item Matcher|Quotation PO-Item Matcher]]
- [[_COMMUNITY_Express App Entrypoint|Express App Entrypoint]]
- [[_COMMUNITY_Prisma DB Client|Prisma DB Client]]
- [[_COMMUNITY_Stock Alert Routes|Stock Alert Routes]]
- [[_COMMUNITY_Auth Routes|Auth Routes]]
- [[_COMMUNITY_Customer Routes|Customer Routes]]
- [[_COMMUNITY_Gate Pass Routes|Gate Pass Routes]]
- [[_COMMUNITY_Inventory Routes|Inventory Routes]]
- [[_COMMUNITY_Inventory Transfer Routes|Inventory Transfer Routes]]
- [[_COMMUNITY_Invoice Routes|Invoice Routes]]
- [[_COMMUNITY_ION Routes|ION Routes]]
- [[_COMMUNITY_Payment Request Routes|Payment Request Routes]]
- [[_COMMUNITY_Product Routes|Product Routes]]
- [[_COMMUNITY_Purchase Order Routes|Purchase Order Routes]]
- [[_COMMUNITY_Purchase Request Routes|Purchase Request Routes]]
- [[_COMMUNITY_QC Inspection Routes|QC Inspection Routes]]
- [[_COMMUNITY_Report Routes|Report Routes]]
- [[_COMMUNITY_Request Routes (MIV)|Request Routes (MIV)]]
- [[_COMMUNITY_Sale Routes|Sale Routes]]
- [[_COMMUNITY_Unit Routes|Unit Routes]]
- [[_COMMUNITY_User Routes|User Routes]]
- [[_COMMUNITY_Warehouse Routes|Warehouse Routes]]

## God Nodes (most connected - your core abstractions)
1. `authenticate()` - 2 edges
2. `verifyAccessToken()` - 2 edges

## Surprising Connections (you probably didn't know these)
- `authenticate()` --calls--> `verifyAccessToken()`  [INFERRED]
  src\middleware\auth.js → src\utils\jwt.js

## Communities

### Community 0 - "JWT Token Utilities"
Cohesion: 0.5
Nodes (0): 

### Community 1 - "Authentication Middleware"
Cohesion: 0.67
Nodes (2): authenticate(), verifyAccessToken()

### Community 2 - "RBAC Authorization"
Cohesion: 0.67
Nodes (0): 

### Community 3 - "Helpers (order numbers, pagination)"
Cohesion: 0.67
Nodes (0): 

### Community 4 - "Admin Seeder"
Cohesion: 1.0
Nodes (0): 

### Community 5 - "Seed Data Script"
Cohesion: 1.0
Nodes (0): 

### Community 6 - "DB Seed Script"
Cohesion: 1.0
Nodes (0): 

### Community 7 - "Audit Logger"
Cohesion: 1.0
Nodes (0): 

### Community 8 - "Quotation PO-Item Matcher"
Cohesion: 1.0
Nodes (0): 

### Community 9 - "Express App Entrypoint"
Cohesion: 1.0
Nodes (0): 

### Community 10 - "Prisma DB Client"
Cohesion: 1.0
Nodes (0): 

### Community 11 - "Stock Alert Routes"
Cohesion: 1.0
Nodes (0): 

### Community 12 - "Auth Routes"
Cohesion: 1.0
Nodes (0): 

### Community 13 - "Customer Routes"
Cohesion: 1.0
Nodes (0): 

### Community 14 - "Gate Pass Routes"
Cohesion: 1.0
Nodes (0): 

### Community 15 - "Inventory Routes"
Cohesion: 1.0
Nodes (0): 

### Community 16 - "Inventory Transfer Routes"
Cohesion: 1.0
Nodes (0): 

### Community 17 - "Invoice Routes"
Cohesion: 1.0
Nodes (0): 

### Community 18 - "ION Routes"
Cohesion: 1.0
Nodes (0): 

### Community 19 - "Payment Request Routes"
Cohesion: 1.0
Nodes (0): 

### Community 20 - "Product Routes"
Cohesion: 1.0
Nodes (0): 

### Community 21 - "Purchase Order Routes"
Cohesion: 1.0
Nodes (0): 

### Community 22 - "Purchase Request Routes"
Cohesion: 1.0
Nodes (0): 

### Community 23 - "QC Inspection Routes"
Cohesion: 1.0
Nodes (0): 

### Community 24 - "Report Routes"
Cohesion: 1.0
Nodes (0): 

### Community 25 - "Request Routes (MIV)"
Cohesion: 1.0
Nodes (0): 

### Community 26 - "Sale Routes"
Cohesion: 1.0
Nodes (0): 

### Community 27 - "Unit Routes"
Cohesion: 1.0
Nodes (0): 

### Community 28 - "User Routes"
Cohesion: 1.0
Nodes (0): 

### Community 29 - "Warehouse Routes"
Cohesion: 1.0
Nodes (0): 

## Knowledge Gaps
- **Thin community `Admin Seeder`** (2 nodes): `addAdmins()`, `add-admins.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Seed Data Script`** (2 nodes): `seed-data.js`, `main()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `DB Seed Script`** (2 nodes): `seed.js`, `main()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Audit Logger`** (2 nodes): `auditLog()`, `audit.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Quotation PO-Item Matcher`** (2 nodes): `matchPRItem()`, `quotation.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Express App Entrypoint`** (1 nodes): `index.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Prisma DB Client`** (1 nodes): `db.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Stock Alert Routes`** (1 nodes): `alert.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Auth Routes`** (1 nodes): `auth.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Customer Routes`** (1 nodes): `customer.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Gate Pass Routes`** (1 nodes): `gatepass.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Inventory Routes`** (1 nodes): `inventory.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Inventory Transfer Routes`** (1 nodes): `inventoryTransfer.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Invoice Routes`** (1 nodes): `invoice.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `ION Routes`** (1 nodes): `ion.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Payment Request Routes`** (1 nodes): `paymentRequest.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Product Routes`** (1 nodes): `product.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Purchase Order Routes`** (1 nodes): `purchaseOrder.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Purchase Request Routes`** (1 nodes): `purchaseRequest.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `QC Inspection Routes`** (1 nodes): `qcInspection.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Report Routes`** (1 nodes): `report.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Request Routes (MIV)`** (1 nodes): `request.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Sale Routes`** (1 nodes): `sale.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Unit Routes`** (1 nodes): `unit.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `User Routes`** (1 nodes): `user.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Warehouse Routes`** (1 nodes): `warehouse.routes.js`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `verifyAccessToken()` connect `Authentication Middleware` to `JWT Token Utilities`?**
  _High betweenness centrality (0.009) - this node is a cross-community bridge._