"""Count valid rows for major data sheets."""
import os, sys
from openpyxl import load_workbook

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

FOLDER = r"C:\Users\alaja\Documents\RAPS formats and stocks"

def count_nonempty(path, sheet, header_row):
    wb = load_workbook(path, data_only=True, read_only=True)
    ws = wb[sheet]
    count = 0
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i < header_row:  # skip header
            continue
        if any(c is not None and str(c).strip() for c in row):
            count += 1
    wb.close()
    return count

cases = [
    ("NEW STOCK.xlsx", "DB", 2),
    ("Stock Demo-1.xlsx", "Items", 1),
    ("IN-2025.xlsx", "INWARD-2025", 3),
    ("IN-2026.xlsx", "INWARD-2026", 1),
    ("Inward Status File.xlsx", "2025-26", 1),
    ("PR & PO File 2026-27.xlsx", "PR & PO ", 1),
    ("PR & PO File 2026-27.xlsx", "PO Sheet", 1),
    ("PR & PO File 2026-27.xlsx", "2025-26 PR", 1),
    ("PR & PO File 2026-27.xlsx", "2025-26 PO", 1),
    ("PR & PO File 2026-27.xlsx", "PR & PO 2025-26", 1),
    ("RAPS PR & PO File Final 2025-2026.xlsx", "Final", 1),
]

for f, s, h in cases:
    p = os.path.join(FOLDER, f)
    try:
        n = count_nonempty(p, s, h)
        print(f"{f} | {s} | {n} data rows")
    except Exception as e:
        print(f"{f} | {s} | ERROR: {e}")
